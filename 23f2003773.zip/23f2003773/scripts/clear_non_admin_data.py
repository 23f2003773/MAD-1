import os
import sys
import shutil
from datetime import datetime

# Ensure project root is on sys.path so `from app import ...` works when run from any cwd
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from app import app, db, Admin, Department, Doctor, Patient, Appointment, Treatment, Blacklist


def find_db_path():
    uri = app.config.get('SQLALCHEMY_DATABASE_URI', '')
    db_path = None
    if uri.startswith('sqlite:///'):
        db_path = uri.replace('sqlite:///', '')
        if not os.path.isabs(db_path):
            db_path = os.path.join(app.root_path, db_path)

    # Prefer instance/hospital.db if present
    inst_path = os.path.join(app.root_path, 'instance', 'hospital.db')
    if os.path.exists(inst_path):
        return inst_path

    if db_path and os.path.exists(db_path):
        return db_path

    # fallback: common names in instance
    fallback = os.path.join(app.root_path, 'instance', 'hospital.db')
    return fallback


def backup_db(db_file):
    if not os.path.exists(os.path.dirname(db_file)):
        os.makedirs(os.path.dirname(db_file), exist_ok=True)
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_name = os.path.join(os.path.dirname(db_file), f'hospital_backup_{ts}.db')
    shutil.copy2(db_file, backup_name)
    return backup_name


def clear_non_admin_data():
    db_file = find_db_path()
    if not os.path.exists(db_file):
        print(f"Database file not found at expected location: {db_file}")
        # Still proceed via ORM (in-memory) if possible
    else:
        backup = backup_db(db_file)
        print(f"Backed up DB to: {backup}")

    with app.app_context():
        try:
            print('Counts before:')
            print('Admins:', Admin.query.count())
            print('Departments:', Department.query.count())
            print('Doctors:', Doctor.query.count())
            print('Patients:', Patient.query.count())
            print('Appointments:', Appointment.query.count())
            print('Treatments:', Treatment.query.count())
            print('Blacklist:', Blacklist.query.count())

            # Delete in safe order (children before parents)
            Treatment.query.delete()
            db.session.commit()

            Appointment.query.delete()
            db.session.commit()

            Blacklist.query.delete()
            db.session.commit()

            Doctor.query.delete()
            db.session.commit()

            Patient.query.delete()
            db.session.commit()

            # Note: we keep Admin and Department records

            print('\nCounts after:')
            print('Admins:', Admin.query.count())
            print('Departments:', Department.query.count())
            print('Doctors:', Doctor.query.count())
            print('Patients:', Patient.query.count())
            print('Appointments:', Appointment.query.count())
            print('Treatments:', Treatment.query.count())
            print('Blacklist:', Blacklist.query.count())

            print('\nCleanup completed successfully.')
        except Exception as e:
            db.session.rollback()
            print('Error during cleanup:', e)


if __name__ == '__main__':
    clear_non_admin_data()
