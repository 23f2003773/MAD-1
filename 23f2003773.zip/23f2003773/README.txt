# Hospital Management app

This README describes how to set up, run and test the app.

Prerequisites

  Python 3.8+ installed
  (recommended) Use a virtual environment

Install & run 

Open a terminal in the project folder and run:

python -m venv venv

venv\Scripts\activate

pip install --upgrade pip
pip install -r pip install flask flask_sqlalchemy werkzeug

python app.py

http://127.0.0.1:5000


username: admin

password: admin123
