from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///hospital.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# ==================== MODELS ====================

class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Department(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    description = db.Column(db.Text)
    doctors = db.relationship('Doctor', backref='department', lazy=True)

class Doctor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(15), nullable=False)
    specialization_id = db.Column(db.Integer, db.ForeignKey('department.id'), nullable=False)
    available = db.Column(db.Boolean, default=True)
    experience_years = db.Column(db.Integer, default=0)
    is_blacklisted = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    appointments = db.relationship('Appointment', backref='doctor', lazy=True, cascade='all, delete-orphan')

class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(15), nullable=False)
    age = db.Column(db.Integer)
    gender = db.Column(db.String(10))
    address = db.Column(db.Text)
    is_blacklisted = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    appointments = db.relationship('Appointment', backref='patient', lazy=True, cascade='all, delete-orphan')

class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    time = db.Column(db.String(10), nullable=False)
    status = db.Column(db.String(20), default='Booked')  # Booked, Completed, Cancelled
    reason = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    treatment = db.relationship('Treatment', backref='appointment', uselist=False, cascade='all, delete-orphan')

class Treatment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    appointment_id = db.Column(db.Integer, db.ForeignKey('appointment.id'), nullable=False)
    diagnosis = db.Column(db.Text, nullable=False)
    prescription = db.Column(db.Text)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Blacklist(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_type = db.Column(db.String(10), nullable=False)  # 'doctor' or 'patient'
    user_id = db.Column(db.Integer, nullable=False)
    reason = db.Column(db.Text, nullable=False)
    blacklisted_by = db.Column(db.Integer, db.ForeignKey('admin.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    admin = db.relationship('Admin', backref='blacklist_actions')

# ==================== DECORATORS ====================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to access this page', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'admin':
            flash('Admin access required', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def doctor_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'doctor':
            flash('Doctor access required', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def patient_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'patient':
            flash('Patient access required', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# ==================== ROUTES ====================

@app.route('/')
def index():
    if 'user_id' in session:
        role = session.get('role')
        if role == 'admin':
            return redirect(url_for('admin_dashboard'))
        elif role == 'doctor':
            return redirect(url_for('doctor_dashboard'))
        elif role == 'patient':
            return redirect(url_for('patient_dashboard'))
    return redirect(url_for('login'))

# ==================== AUTH ROUTES ====================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')

        user = None
        if role == 'admin':
            user = Admin.query.filter_by(username=username).first()
        elif role == 'doctor':
            user = Doctor.query.filter_by(username=username).first()
        elif role == 'patient':
            user = Patient.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            # Check if user is blacklisted
            if hasattr(user, 'is_blacklisted') and user.is_blacklisted:
                flash('Your account has been blacklisted. Please contact administration.', 'error')
                return render_template('login.html')
            
            session['user_id'] = user.id
            session['role'] = role
            session['name'] = user.name
            flash(f'Welcome {user.name}!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid credentials', 'error')

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        age = request.form.get('age')
        gender = request.form.get('gender')
        address = request.form.get('address')

        # Check if username or email exists
        if Patient.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return redirect(url_for('register'))
        
        if Patient.query.filter_by(email=email).first():
            flash('Email already exists', 'error')
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password)
        new_patient = Patient(
            username=username,
            password=hashed_password,
            name=name,
            email=email,
            phone=phone,
            age=age,
            gender=gender,
            address=address
        )
        
        db.session.add(new_patient)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('login'))

# ==================== ADMIN ROUTES ====================

@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    total_doctors = Doctor.query.count()
    total_patients = Patient.query.count()
    total_appointments = Appointment.query.count()
    today = datetime.now().date()
    today_appointments = Appointment.query.filter_by(date=today).count()
    
    recent_appointments = Appointment.query.order_by(Appointment.created_at.desc()).limit(10).all()
    
    return render_template('admin/dashboard.html',
                         total_doctors=total_doctors,
                         total_patients=total_patients,
                         total_appointments=total_appointments,
                         today_appointments=today_appointments,
                         recent_appointments=recent_appointments)

@app.route('/admin/doctors', methods=['GET', 'POST'])
@admin_required
def admin_doctors():
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'add':
            username = request.form.get('username')
            password = request.form.get('password')
            name = request.form.get('name')
            email = request.form.get('email')
            phone = request.form.get('phone')
            specialization_id = request.form.get('specialization_id')
            experience_years = request.form.get('experience_years', 0)
            
            hashed_password = generate_password_hash(password)
            new_doctor = Doctor(
                username=username,
                password=hashed_password,
                name=name,
                email=email,
                phone=phone,
                specialization_id=specialization_id,
                experience_years=experience_years
            )
            
            db.session.add(new_doctor)
            db.session.commit()
            flash('Doctor added successfully', 'success')
        
        elif action == 'update':
            doctor_id = request.form.get('doctor_id')
            doctor = Doctor.query.get(doctor_id)
            if doctor:
                doctor.name = request.form.get('name')
                doctor.email = request.form.get('email')
                doctor.phone = request.form.get('phone')
                doctor.specialization_id = request.form.get('specialization_id')
                doctor.experience_years = request.form.get('experience_years', 0)
                doctor.available = request.form.get('available') == '1'
                db.session.commit()
                flash('Doctor updated successfully', 'success')
        
        elif action == 'delete':
            doctor_id = request.form.get('doctor_id')
            doctor = Doctor.query.get(doctor_id)
            if doctor:
                db.session.delete(doctor)
                db.session.commit()
                flash('Doctor removed successfully', 'success')
        
        return redirect(url_for('admin_doctors'))
    
    search = request.args.get('search', '')
    if search:
        doctors = Doctor.query.filter(
            (Doctor.name.contains(search)) | 
            (Doctor.email.contains(search))
        ).all()
    else:
        doctors = Doctor.query.all()
    
    departments = Department.query.order_by(Department.name).all()
    return render_template('admin/doctors.html', doctors=doctors, departments=departments)

@app.route('/admin/patients', methods=['GET', 'POST'])
@admin_required
def admin_patients():
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'delete':
            patient_id = request.form.get('patient_id')
            patient = Patient.query.get(patient_id)
            if patient:
                db.session.delete(patient)
                db.session.commit()
                flash('Patient removed successfully', 'success')
        
        return redirect(url_for('admin_patients'))
    
    search = request.args.get('search', '')
    if search:
        patients = Patient.query.filter(
            (Patient.name.contains(search)) | 
            (Patient.email.contains(search)) |
            (Patient.phone.contains(search))
        ).all()
    else:
        patients = Patient.query.all()
    
    return render_template('admin/patients.html', patients=patients)

@app.route('/admin/appointments')
@admin_required
def admin_appointments():
    appointments = Appointment.query.order_by(Appointment.date.desc()).all()
    return render_template('admin/appointments.html', appointments=appointments)

@app.route('/admin/blacklist')
@admin_required
def admin_blacklist():
    blacklist_entries = Blacklist.query.order_by(Blacklist.created_at.desc()).all()
    return render_template('admin/blacklist.html', blacklist_entries=blacklist_entries)

@app.route('/admin/blacklist_doctor/<int:doctor_id>', methods=['POST'])
@admin_required
def blacklist_doctor(doctor_id):
    doctor = Doctor.query.get(doctor_id)
    if doctor:
        reason = request.form.get('reason', 'No reason provided')
        admin_id = session.get('user_id')
        
        # Add to blacklist
        blacklist_entry = Blacklist(
            user_type='doctor',
            user_id=doctor_id,
            reason=reason,
            blacklisted_by=admin_id
        )
        doctor.is_blacklisted = True
        db.session.add(blacklist_entry)
        db.session.commit()
        flash(f'Doctor {doctor.name} has been blacklisted', 'success')
    
    return redirect(request.referrer or url_for('admin_doctors'))

@app.route('/admin/blacklist_patient/<int:patient_id>', methods=['POST'])
@admin_required
def blacklist_patient(patient_id):
    patient = Patient.query.get(patient_id)
    if patient:
        reason = request.form.get('reason', 'No reason provided')
        admin_id = session.get('user_id')
        
        # Add to blacklist
        blacklist_entry = Blacklist(
            user_type='patient',
            user_id=patient_id,
            reason=reason,
            blacklisted_by=admin_id
        )
        patient.is_blacklisted = True
        db.session.add(blacklist_entry)
        db.session.commit()
        flash(f'Patient {patient.name} has been blacklisted', 'success')
    
    return redirect(request.referrer or url_for('admin_patients'))

@app.route('/admin/remove_from_blacklist/<int:blacklist_id>', methods=['POST'])
@admin_required
def remove_from_blacklist(blacklist_id):
    blacklist_entry = Blacklist.query.get(blacklist_id)
    if blacklist_entry:
        if blacklist_entry.user_type == 'doctor':
            doctor = Doctor.query.get(blacklist_entry.user_id)
            if doctor:
                doctor.is_blacklisted = False
                flash(f'Doctor {doctor.name} has been removed from blacklist', 'success')
        else:
            patient = Patient.query.get(blacklist_entry.user_id)
            if patient:
                patient.is_blacklisted = False
                flash(f'Patient {patient.name} has been removed from blacklist', 'success')
        
        db.session.delete(blacklist_entry)
        db.session.commit()
    
    return redirect(url_for('admin_blacklist'))

# ==================== DOCTOR ROUTES ====================

@app.route('/doctor/dashboard')
@doctor_required
def doctor_dashboard():
    doctor_id = session.get('user_id')
    today = datetime.now().date()
    
    today_appointments = Appointment.query.filter_by(
        doctor_id=doctor_id,
        date=today,
        status='Booked'
    ).all()
    
    total_patients = db.session.query(Appointment.patient_id).filter_by(
        doctor_id=doctor_id
    ).distinct().count()
    
    completed_today = Appointment.query.filter_by(
        doctor_id=doctor_id,
        date=today,
        status='Completed'
    ).count()
    
    return render_template('doctor/dashboard.html',
                         today_appointments=today_appointments,
                         total_patients=total_patients,
                         completed_today=completed_today)

@app.route('/doctor/appointments')
@doctor_required
def doctor_appointments():
    doctor_id = session.get('user_id')
    appointments = Appointment.query.filter_by(doctor_id=doctor_id).order_by(Appointment.date.desc()).all()
    return render_template('doctor/appointments.html', appointments=appointments)

@app.route('/doctor/complete_appointment/<int:appointment_id>', methods=['GET', 'POST'])
@doctor_required
def complete_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    
    if request.method == 'POST':
        diagnosis = request.form.get('diagnosis')
        prescription = request.form.get('prescription')
        notes = request.form.get('notes')
        
        treatment = Treatment(
            appointment_id=appointment_id,
            diagnosis=diagnosis,
            prescription=prescription,
            notes=notes
        )
        
        appointment.status = 'Completed'
        
        db.session.add(treatment)
        db.session.commit()
        
        flash('Appointment completed successfully', 'success')
        return redirect(url_for('doctor_appointments'))
    
    return render_template('doctor/complete_appointment.html', appointment=appointment)

@app.route('/doctor/cancel_appointment/<int:appointment_id>', methods=['POST'])
@doctor_required
def doctor_cancel_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    appointment.status = 'Cancelled'
    db.session.commit()
    flash('Appointment cancelled', 'success')
    return redirect(url_for('doctor_appointments'))

@app.route('/doctor/patients')
@doctor_required
def doctor_patients():
    doctor_id = session.get('user_id')
    patient_ids = db.session.query(Appointment.patient_id).filter_by(doctor_id=doctor_id).distinct().all()
    patient_ids = [p[0] for p in patient_ids]
    patients = Patient.query.filter(Patient.id.in_(patient_ids)).all()
    
    return render_template('doctor/patients.html', patients=patients)

@app.route('/doctor/patient_history/<int:patient_id>')
@doctor_required
def patient_history(patient_id):
    doctor_id = session.get('user_id')
    patient = Patient.query.get_or_404(patient_id)
    
    appointments = Appointment.query.filter_by(
        patient_id=patient_id,
        doctor_id=doctor_id,
        status='Completed'
    ).order_by(Appointment.date.desc()).all()
    
    return render_template('doctor/patient_history.html', patient=patient, appointments=appointments)

# ==================== PATIENT ROUTES ====================

@app.route('/patient/dashboard')
@patient_required
def patient_dashboard():
    patient_id = session.get('user_id')
    departments = Department.query.all()
    upcoming_appointments = Appointment.query.filter_by(
        patient_id=patient_id,
        status='Booked'
    ).order_by(Appointment.date).all()
    
    return render_template('patient/dashboard.html',
                         departments=departments,
                         upcoming_appointments=upcoming_appointments)

@app.route('/patient/doctors')
@patient_required
def patient_doctors():
    search = request.args.get('search', '')
    specialization_id = request.args.get('specialization', '')
    
    query = Doctor.query
    
    if search:
        query = query.filter(Doctor.name.contains(search))
    
    if specialization_id:
        query = query.filter_by(specialization_id=specialization_id)
    
    doctors = query.filter_by(available=True).all()
    departments = Department.query.order_by(Department.name).all()
    
    return render_template('patient/doctors.html', doctors=doctors, departments=departments)

@app.route('/patient/book_appointment/<int:doctor_id>', methods=['GET', 'POST'])
@patient_required
def book_appointment(doctor_id):
    doctor = Doctor.query.get_or_404(doctor_id)
    
    if request.method == 'POST':
        date_str = request.form.get('date')
        time = request.form.get('time')
        reason = request.form.get('reason')
        
        appointment_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        
        # Check for existing appointment
        existing = Appointment.query.filter_by(
            doctor_id=doctor_id,
            date=appointment_date,
            time=time,
            status='Booked'
        ).first()
        
        if existing:
            flash('This time slot is already booked. Please choose another time.', 'error')
            return redirect(url_for('book_appointment', doctor_id=doctor_id))
        
        new_appointment = Appointment(
            patient_id=session.get('user_id'),
            doctor_id=doctor_id,
            date=appointment_date,
            time=time,
            reason=reason,
            status='Booked'
        )
        
        db.session.add(new_appointment)
        db.session.commit()
        
        flash('Appointment booked successfully!', 'success')
        return redirect(url_for('patient_appointments'))
    
    return render_template('patient/book_appointment.html', doctor=doctor)

@app.route('/patient/appointments')
@patient_required
def patient_appointments():
    patient_id = session.get('user_id')
    appointments = Appointment.query.filter_by(patient_id=patient_id).order_by(Appointment.date.desc()).all()
    return render_template('patient/appointments.html', appointments=appointments)

@app.route('/patient/cancel_appointment/<int:appointment_id>', methods=['POST'])
@patient_required
def cancel_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    
    if appointment.patient_id != session.get('user_id'):
        flash('Unauthorized', 'error')
        return redirect(url_for('patient_appointments'))
    
    appointment.status = 'Cancelled'
    db.session.commit()
    
    flash('Appointment cancelled successfully', 'success')
    return redirect(url_for('patient_appointments'))

@app.route('/patient/treatment_history')
@patient_required
def treatment_history():
    patient_id = session.get('user_id')
    completed_appointments = Appointment.query.filter_by(
        patient_id=patient_id,
        status='Completed'
    ).order_by(Appointment.date.desc()).all()
    
    return render_template('patient/treatment_history.html', appointments=completed_appointments)

@app.route('/patient/profile', methods=['GET', 'POST'])
@patient_required
def patient_profile():
    patient_id = session.get('user_id')
    patient = Patient.query.get_or_404(patient_id)
    
    if request.method == 'POST':
        patient.name = request.form.get('name')
        patient.email = request.form.get('email')
        patient.phone = request.form.get('phone')
        patient.age = request.form.get('age')
        patient.gender = request.form.get('gender')
        patient.address = request.form.get('address')
        
        db.session.commit()
        flash('Profile updated successfully', 'success')
        return redirect(url_for('patient_profile'))
    
    return render_template('patient/profile.html', patient=patient)

# ==================== INITIALIZE DATABASE ====================

def init_db():
    with app.app_context():
        db.create_all()
        
        # Create admin if not exists
        if not Admin.query.filter_by(username='admin').first():
            admin = Admin(
                username='admin',
                password=generate_password_hash('admin123'),
                name='Hospital Administrator',
                email='admin@hospital.com'
            )
            db.session.add(admin)
        
        # List of all medical specializations
        all_departments = [
            {'name': 'Cardiology', 'description': 'Heart and cardiovascular system'},
            {'name': 'Orthopedics', 'description': 'Bones and joints'},
            {'name': 'Pediatrics', 'description': 'Child healthcare'},
            {'name': 'Neurology', 'description': 'Brain and nervous system'},
            {'name': 'Dermatology', 'description': 'Skin conditions'},
            {'name': 'General Surgery', 'description': 'Surgical operations for various conditions'},
            {'name': 'Gynecology', 'description': 'Female reproductive health'},
            {'name': 'Ophthalmology', 'description': 'Eye care and surgery'},
            {'name': 'Psychiatry', 'description': 'Mental health and behavioral disorders'},
            {'name': 'ENT', 'description': 'Ear, Nose, and Throat conditions'},
            {'name': 'Oncology', 'description': 'Cancer treatment and care'},
            {'name': 'Dental', 'description': 'Oral health and dentistry'},
            {'name': 'Urology', 'description': 'Urinary tract and male reproductive system'},
            {'name': 'Gastroenterology', 'description': 'Digestive system disorders'},
            {'name': 'Pulmonology', 'description': 'Lung and respiratory system'},
            {'name': 'Nephrology', 'description': 'Kidney diseases and care'},
            {'name': 'Endocrinology', 'description': 'Hormone and thyroid issues'}
        ]
        
        # Add departments if they don't exist
        for dept_data in all_departments:
            if not Department.query.filter_by(name=dept_data['name']).first():
                new_dept = Department(name=dept_data['name'], description=dept_data['description'])
                db.session.add(new_dept)
        
        db.session.commit()
        print("Database initialized successfully!")

if __name__ == '__main__':
    init_db()
    app.run(debug=True)